DROP TABLE IF EXISTS products;

CREATE TABLE products  (
  id INT AUTO_INCREMENT  PRIMARY KEY,
  product_name VARCHAR(250) NOT NULL,
  product_type VARCHAR(250) NOT NULL,
  expire_date  DATE NOT NULL,
  quantity INT,
  tobuy  VARCHAR(250) NOT NULL
);

