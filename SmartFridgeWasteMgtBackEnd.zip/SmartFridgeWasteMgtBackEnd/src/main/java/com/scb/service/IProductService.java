package com.scb.service;

import com.scb.model.Product;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.util.List;
@Service
public interface IProductService {
    public void addProduct(Product product) throws ParseException;
    public List<Product> getAllProducts();
    public List<Product> getProductByType(String productType);
    public void deleteProduct(Product product);
    public Long updateProduct(Product product);
    public List<Product> getBasedOnExpireDate();


}
