package com.scb.service;

import com.scb.model.Product;
import com.scb.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ProductServiceImpl implements IProductService {
    @Autowired
    public ProductRepository productRepository;

    @Override
    public void addProduct(Product product) {
        productRepository.save(product);

    }

    @Override
    public List<Product> getAllProducts() {
        return (List<Product>) productRepository.findAll();
    }

    @Override
    public List<Product> getProductByType(String productType) {
        List<Product> productList = getAllProducts();
        List<Product> productListByType;
        productListByType = productList.stream()
                .filter(product -> product.getProductType()
                        .equalsIgnoreCase(productType))
                .collect(Collectors.toList());
        return productListByType;
    }

    @Override
    public void deleteProduct(Product product) {
        productRepository.delete(product);
    }

    @Override
    public Long updateProduct(Product product) {
        Optional<Product> productNew = productRepository.findById(product.getId());
        Product prod = productNew.get();
        prod.setProductName(product.getProductName());
        prod.setProductType(product.getProductType());
        prod.setExpiryDate(product.getExpiryDate());
        prod.setQuantities(product.getQuantities());
        prod.setToBuy(product.getToBuy());
        productRepository.save(prod);

        return prod.getId();
    }

    @Override
    public List<Product> getBasedOnExpireDate() {
        List<Product> productList = (List<Product>) productRepository.findAll();
        if (productList != null && !productList.isEmpty()) {
            productList.sort(Comparator.comparing(Product::getExpiryDate));
        }


        return productList;
    }
}
