package com.scb.controller;

import com.scb.model.Product;
import com.scb.service.IProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.text.ParseException;
import java.util.List;

@RestController
public class ProductController {
    @Autowired
    private IProductService productService;

    @PostMapping("/product/add")
    public void saveProduct(@RequestBody Product product) throws ParseException {
        productService.addProduct(product);
    }

    @GetMapping("/product/{productType}")
    public List<Product> getProductListByType(@PathVariable String productType) {
        return productService.getProductByType(productType);
    }

    @PostMapping("/product/update")
    public Long updateProduct(@RequestBody Product product) {
        return productService.updateProduct(product);
    }

    @GetMapping("/product/getAllbyexpiredate")
    public List<Product> getProductByExpireDate() {
        return productService.getBasedOnExpireDate();
    }
    @GetMapping("/product/getallproducts")
    public List<Product> getAllProduct() {
        return productService.getAllProducts();
    }
}
