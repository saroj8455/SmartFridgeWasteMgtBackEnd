package com.scb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartFridgeWasteMgtBackEndApplicationTests {

	@Test
	void contextLoads() {
	}

}
