import { Injectable } from "@angular/core";
import { Item } from "./item";

@Injectable({
  providedIn: "root",
})
export class ItemServiceService {
  // automatic incrementing of ids
  lastId: number = 0;
  itemList: Item[] = [];
  constructor() {}

  addItem(item: Item): ItemServiceService {
    let newItem: Item = new Item();
    newItem.id = ++this.lastId;
    newItem.productName = item.productName;
    newItem.productType = item.productType;
    newItem.quantities = item.quantities;
    newItem.expiryDate = item.expiryDate;
    newItem.toBuy = item.toBuy;
    this.itemList.push(newItem);
    return this;
  }

  deleteItemById(id: number): ItemServiceService {
    this.itemList = this.itemList.filter((item) => item.id !== id);
    return this;
  }

  updateById(id: number, values: Object = {}): Item {
    let item = this.getItemById(id);
    if (!item) {
      return null;
    }
    Object.assign(item, values);
    return item;
  }

  getAllItems() {
    return this.itemList;
  }

  getItemById(id: number): Item {
    return this.itemList.filter((item) => item.id === id).pop();
  }

  private getTime(date?: Date) {
    return date != null ? date.getTime() : 0;
  }

  public sortByExpireDate(): void {
    this.itemList.sort((a: Item, b: Item) => {
      return this.getTime(a.expiryDate) - this.getTime(b.expiryDate);
    });
  }
}
