export class Item {
public id: number;
public productName: string;
public productType:string;
public quantities:number;
public expiryDate:Date;
public toBuy: string;

constructor(values: Object = {}) {
    Object.assign(this, values);
  }
}