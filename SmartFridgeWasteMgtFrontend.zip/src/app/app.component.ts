import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ItemServiceService } from './item-service.service';
import { Item } from './item';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  constructor(private itemService:ItemServiceService)
  {

  }
  title = 'App';
  itemModel: Item = new Item();
  allItems : Item[] = [];
  isSave : boolean = false;


  ngOnInit() {
    
    console.log(this.itemService.getAllItems());
    
  }
  onSubmit() {
    console.log(this.itemModel);
    this.itemService.addItem(this.itemModel);
    this.isSave = true;

  }
  showItems() {
    this.allItems = this.itemService.getAllItems();
    
  }



}
